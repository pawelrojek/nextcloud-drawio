<?php

namespace OCA\Drawio\AppInfo;

use OCP\App;

App::registerAdmin("drawio", "settings");

$app = new Application();
