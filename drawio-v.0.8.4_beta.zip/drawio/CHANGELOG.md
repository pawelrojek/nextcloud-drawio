# Change Log

## 0.8.4
- Initial release (beta version)